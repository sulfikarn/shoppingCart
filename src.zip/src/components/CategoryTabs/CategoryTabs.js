import React, { Fragment, useCallback, useEffect, memo } from 'react'
// import { fetchProducts } from '../../api/ProductApi';
import { useDispatch, useSelector } from 'react-redux';
import { addItem, incrementQuantity, decrementQuantity, removeItem } from '../../redux/cart';
import { setActiveCategory } from '../../redux/category';
import { Container } from 'react-bootstrap';

const CategoryTabs = () => {
    const categoryList = useSelector(state=>state?.cart?.items[0])

    // const seActive = useSelector(state=>state?.cart?.items[0])
    const dispatch = useDispatch(); 

    useEffect(() => {
        if(categoryList && categoryList.length > 0){
            dispatch(setActiveCategory(categoryList[1].menu_category_id ))
        }
      },[categoryList]);


      
    const handleClick = (category) => {
        dispatch(setActiveCategory(category));
    };

    return (
        <Container>
            <ul className="nav nav-tabs border-0">
                {categoryList?.map( category => 
                    <li className="nav-item border-bottom border-danger" key="1">
                        <button
                            className="nav-link border-0"
                            onClick={() => handleClick(category.menu_category_id)}
                        >
                            {category.menu_category}  
                        </button>
                    </li>
                    )}
            </ul>
        </Container>

    );
};

export default CategoryTabs;
