import React, { Fragment } from 'react'
import { Container, Navbar } from 'react-bootstrap';
import { useSelector } from 'react-redux';
function Header() {
  const cartData = useSelector(state=>state.cart.items[0])

  // console.log("cartData===", cartData)
  var shopName= ''
  let totalCart=0
  cartData && cartData.forEach((item)=> {
    if(typeof(item) !== 'string'){
      var category_dishes = item["category_dishes"]
      category_dishes.forEach((dish_item) => {
      totalCart+= dish_item.quantity;
    })
    } else {
      shopName = item
    }
  })

  return (
    <Fragment>
      <Navbar className="bg-body-tertiary">
      <Container>
        <Navbar.Brand href="#home">{shopName}</Navbar.Brand>
        <Navbar.Toggle />
        <Navbar.Collapse className="justify-content-end">
          <Navbar.Text>
            Cart <span>{totalCart}</span>
          </Navbar.Text>
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </Fragment>
  )
}

export default Header
