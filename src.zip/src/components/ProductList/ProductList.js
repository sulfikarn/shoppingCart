import React, { Fragment, useEffect, useState } from 'react'
import { addItem, incrementQuantity, decrementQuantity, removeItem } from '../../redux/cart';
import { selectActiveCategory } from '../../redux/category';
import { useDispatch, useSelector } from 'react-redux';
import { Container } from 'react-bootstrap';
import { fetchProducts } from '../../api/ProductApi';
import './ProductList.css'


function ProductList() {
    const activeCategory = useSelector(selectActiveCategory);
    const productsDish = useSelector(state => state?.cart?.items[0])
    const dispatch = useDispatch();

    useEffect(() => {
        const fetchDataAsync = async () => {
            try {
                const fetchData = await fetchProducts();
                let shopName = fetchData.data[0].restaurant_name
                let restaurant = [shopName];
                fetchData.data[0].table_menu_list.forEach(product => {
                    var category_dishes = product["category_dishes"]
                    category_dishes.forEach(dishList => {
                        dishList.quantity = 0;
                    });
                    restaurant.push(product)

                });
                dispatch(addItem(restaurant))

            } catch (error) {
                // Handle error, e.g., show an error message to the user
            }
        };

        fetchDataAsync();
    }, [dispatch]);

    const activeData = productsDish?.find((item) => item.menu_category_id === activeCategory);


    const handleIncrement = (categoryId, dishId) => {
        dispatch(incrementQuantity({ catId: categoryId, dishId: dishId }));
    }

    const handleDecrement = (categoryId, dishId) => {
        dispatch(decrementQuantity({ catId: categoryId, dishId: dishId }));
    }

    return (

        <Fragment>
            <Container>
                <div className='row justify-content-md-center mt-4'>
                    {activeData?.category_dishes?.map(dishitems =>
                        <>
                            <div className='col-sm-6'>
                                <div className='d-flex flex-column'>
                                    <h5 className='text-primary'>{dishitems.dish_name} </h5>
                                    <p className='text-white'>{dishitems.dish_currency}  {dishitems.dish_price}</p>
                                    <p className='text-white'>{dishitems.dish_description}</p>
                                    <div className="btn-continer bg-success">
                                        <button className="button bg-success" onClick={() => handleDecrement(activeCategory, dishitems.dish_id)}>-</button>
                                        <span className="count">{dishitems.quantity}</span>
                                        <button className="button bg-success" onClick={() => handleIncrement(activeCategory, dishitems.dish_id)}>+</button>
                                    </div>
                                    <p className='text-danger'>Customization available</p>
                                </div>

                            </div>
                            <div className='col-sm-6'>
                                <div className='d-flex justify-content-end align-items-center'>
                                    <h6 className='text-primary pe-2'>{dishitems.dish_calories} Calories</h6>
                                    <div className='w-25'>
                                        <img src={dishitems.dish_image} alt='food' className='img-fluid' />
                                    </div>
                                </div>

                            </div>
                            <hr />
                        </>

                    )}
                </div>
            </Container>
        </Fragment>
    )
}

export default ProductList
